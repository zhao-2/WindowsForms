﻿using System;

namespace WindowsForms
{
    internal class CreateSqlConn
    {
        internal void command(string code)
        {
            throw new NotImplementedException();
        }

        internal void connection()
        {
            throw new NotImplementedException();
        }

        internal int Excute(string code)
        {
            throw new NotImplementedException();
        }
    }
}